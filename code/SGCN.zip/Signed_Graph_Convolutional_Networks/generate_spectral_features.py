###########################################################################################
# generate_spectral_features_Sept29_2018.py
#
# Used to get the spectral embeddings that are later used as input
# into the Signed Graph Convolutional Networks (SGCNs).
# If other node features are existing they can be used instead of or in unison.
#
# Input 1: training_network_file_name.txt 
#          Assumed format is:
#          numV numE
#          u_i u_j sign
#
# Input 2: size of the spectral embedding 
#          i.e., the number of features for the SGCNs
#
# Author: Tyler Derr (derrtyle@msu.edu)
###########################################################################################

import pickle as p
import scipy.sparse as sps
from scipy.sparse.linalg import eigsh, eigs
import numpy as np
import sys

###########################################################################################

def read_in_undirected_graph(file_name):
    with open(file_name) as fp:
        n,m = [int(val) for val in fp.readline().split()]
        #A = numpy.zeros((n,n), dtype=int)
        A = sps.dok_matrix((n,n), dtype=float)
        for l in fp:
            i,j,s = [int(val) for val in l.split()]

            A[i,j] = s
            A[j,i] = s
    A = A.asformat('csr')
    return A

###########################################################################################

def get_D_from_A(A):
    D = sps.lil_matrix((A.shape[0],A.shape[1]), dtype=float)
    DD = np.dot(A,A.T)
    for i in range(A.shape[0]):
        D[i,i] = DD[i,i]
    D = D.asformat('csr')
    return D
    
###########################################################################################
    
if __name__ == "__main__":
    num_to_skip = 0
    training_network_file_name = sys.argv[1]
    A = read_in_undirected_graph(training_network_file_name)
    D = get_D_from_A(A)
    L = D - A
    n = A.shape[0]
    k_to_keep = int(sys.argv[2]) #number of features/spectral embedding size
    
    val, vec = eigsh(L,k=k_to_keep,which='SM',maxiter=100000)
    #val, vec = eigsh(L,k=k_to_keep,which='LM',sigma=0.00001)
    vec = vec[:,num_to_skip:]

    output = sys.argv[1][:-4] + '_features{}.pkl'.format(k_to_keep)
    print('Wrote the file to: {}'.format(output))
    p.dump(vec, open(output,'w'))
